package com.creas.petrecall.command;

import com.creas.petrecall.PetRecallMod;
import com.creas.petrecall.recall.PetRecallService;
import com.creas.petrecall.recall.PetRecallService.RecallSummary;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class PetRecallCommand {
    private PetRecallCommand() {
    }

    public static void register(CommandDispatcher<class_2168> dispatcher, net.minecraft.class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(class_2170.method_9247("petrecall")
                .requires(source -> source.method_9228() instanceof class_3222)
                .executes(PetRecallCommand::executeSelf)
                .then(class_2170.method_9247("rescan")
                        .executes(PetRecallCommand::executeRescan)));
    }

    private static int executeSelf(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();
        if (!player.method_24828()) {
            context.getSource().method_9213(class_2561.method_43470("Stand on the ground before using Pet Recall."));
            return 0;
        }

        if (getService().isRecallActive(player.method_5667())) {
            context.getSource().method_9213(class_2561.method_43470("Pet Recall is already running for you."));
            return 0;
        }

        boolean started = getService().recallAllForPlayerAsync(player, summary -> {
            if (player.method_31481()) {
                return;
            }

            player.method_7353(class_2561.method_43470(
                    "Pet Recall: " + summary.recalled + " recalled, " + summary.skipped + " skipped, " + summary.failed + " failed, " + summary.totalKnown + " indexed."
            ), false);

            if (!summary.messages.isEmpty()) {
                int max = Math.min(summary.messages.size(), 5);
                for (int i = 0; i < max; i++) {
                    player.method_7353(class_2561.method_43470(" - " + summary.messages.get(i)), false);
                }
                if (summary.messages.size() > max) {
                    player.method_7353(class_2561.method_43470(" - ... and " + (summary.messages.size() - max) + " more"), false);
                }
            }
        });

        if (!started) {
            context.getSource().method_9213(class_2561.method_43470("Failed to start Pet Recall."));
            return 0;
        }

        context.getSource().method_9226(() -> class_2561.method_43470("Pet Recall started..."), false);
        return 1;
    }

    private static int executeRescan(CommandContext<class_2168> context) throws CommandSyntaxException {
        class_3222 player = context.getSource().method_9207();
        int found = getService().rescanLoadedForPlayer(player);
        context.getSource().method_9226(
                () -> class_2561.method_43470("Pet Recall: re-indexed " + found + " loaded pets for " + player.method_5477().getString() + "."),
                false
        );
        return found;
    }

    private static PetRecallService getService() {
        return PetRecallMod.getRecallService();
    }
}
