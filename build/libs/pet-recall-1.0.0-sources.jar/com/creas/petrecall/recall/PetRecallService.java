package com.creas.petrecall.recall;

import com.creas.petrecall.PetRecallMod;
import com.creas.petrecall.index.PetRecord;
import com.creas.petrecall.mixin.accessor.EntityChunkDataAccessAccessor;
import com.creas.petrecall.mixin.accessor.ServerEntityManagerAccessor;
import com.creas.petrecall.mixin.accessor.ServerWorldAccessor;
import com.creas.petrecall.runtime.PetTracker;
import com.creas.petrecall.util.PetOwnershipUtil;
import com.creas.petrecall.util.PetOwnershipUtil.OwnedPetData;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Comparator;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_14;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2397;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_3959;
import net.minecraft.class_3977;
import net.minecraft.class_4844;
import net.minecraft.class_5454;
import net.minecraft.class_5565;
import net.minecraft.class_5571;
import net.minecraft.class_5579;
import net.minecraft.class_7;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public final class PetRecallService {
    private final PetTracker tracker;
    private final Set<UUID> activeRecalls = new HashSet<>();
    private final Set<UUID> activePetRecalls = new HashSet<>();

    public PetRecallService(PetTracker tracker) {
        this.tracker = tracker;
    }

    public boolean isRecallActive(UUID playerUuid) {
        synchronized (this.activeRecalls) {
            return this.activeRecalls.contains(playerUuid);
        }
    }

    public boolean recallAllForPlayerAsync(class_3222 player, Consumer<RecallSummary> onComplete) {
        return this.recallForPlayerAsync(player, onComplete, true, true, null, true);
    }

    public boolean recallUnloadedForPlayerAsyncSilent(class_3222 player) {
        return this.recallUnloadedForPlayerAsyncSilent(player, null, summary -> {
            // Silent auto-recall: no chat output, no command-like feedback.
        });
    }

    public boolean recallUnloadedForPlayerAsyncSilent(class_3222 player, List<PetRecord> candidateRecords) {
        return this.recallUnloadedForPlayerAsyncSilent(player, candidateRecords, summary -> {
            // Silent auto-recall with prefiltered candidates.
        });
    }

    public boolean recallUnloadedForPlayerAsyncSilent(
            class_3222 player,
            @Nullable List<PetRecord> candidateRecords,
            Consumer<RecallSummary> onComplete
    ) {
        if (candidateRecords != null && candidateRecords.isEmpty()) {
            return false;
        }
        return this.recallForPlayerAsync(player, onComplete, false, false, candidateRecords, false);
    }

    private boolean recallForPlayerAsync(
            class_3222 player,
            Consumer<RecallSummary> onComplete,
            boolean includeLoadedPets,
            boolean rescanIfEmpty,
            @Nullable List<PetRecord> presetRecords,
            boolean collectMessages
    ) {
        class_3218 targetWorld = player.method_51469();
        MinecraftServer server = targetWorld.method_8503();
        if (server == null) {
            RecallSummary summary = new RecallSummary(collectMessages);
            summary.messages.add("Server is not available");
            summary.failed = 1;
            onComplete.accept(summary);
            return false;
        }

        UUID playerUuid = player.method_5667();
        synchronized (this.activeRecalls) {
            if (!this.activeRecalls.add(playerUuid)) {
                return false;
            }
        }

        if (!player.method_24828()) {
            RecallSummary summary = new RecallSummary(collectMessages);
            summary.messages.add("Stand on the ground before using Pet Recall.");
            summary.failed = 1;
            synchronized (this.activeRecalls) {
                this.activeRecalls.remove(playerUuid);
            }
            onComplete.accept(summary);
            return true;
        }

        List<PetRecord> records = presetRecords == null
                ? new ArrayList<>(this.tracker.getOwnerRecords(server, playerUuid))
                : new ArrayList<>(presetRecords);
        if (records.isEmpty() && rescanIfEmpty && presetRecords == null) {
            this.tracker.rescanLoadedPetsForOwner(server, playerUuid);
            records = new ArrayList<>(this.tracker.getOwnerRecords(server, playerUuid));
        }

        this.sortRecordsForRecall(player, records, includeLoadedPets);

        RecallSummary summary = new RecallSummary(collectMessages);
        summary.totalKnown = records.size();

        this.processNextRecord(player, server, records, 0, summary, onComplete, includeLoadedPets);
        return true;
    }

    private void sortRecordsForRecall(class_3222 player, List<PetRecord> records, boolean includeLoadedPets) {
        String playerDimensionId = player.method_51469().method_27983().method_29177().toString();
        Map<UUID, Boolean> loadedCache = new HashMap<>(Math.max(16, records.size()));
        Comparator<PetRecord> comparator = (a, b) -> {
            if (includeLoadedPets) {
                boolean aLoaded = loadedCache.computeIfAbsent(a.petUuid(), uuid -> this.tracker.getLoadedPet(uuid) != null);
                boolean bLoaded = loadedCache.computeIfAbsent(b.petUuid(), uuid -> this.tracker.getLoadedPet(uuid) != null);
                int loadedCompare = Boolean.compare(bLoaded, aLoaded);
                if (loadedCompare != 0) {
                    return loadedCompare;
                }
            }

            boolean aSameDim = playerDimensionId.equals(a.dimensionId());
            boolean bSameDim = playerDimensionId.equals(b.dimensionId());
            int sameDimCompare = Boolean.compare(bSameDim, aSameDim);
            if (sameDimCompare != 0) {
                return sameDimCompare;
            }

            int dimCompare = a.dimensionId().compareTo(b.dimensionId());
            if (dimCompare != 0) {
                return dimCompare;
            }

            int chunkCompare = Long.compare(a.chunkPosLong(), b.chunkPosLong());
            if (chunkCompare != 0) {
                return chunkCompare;
            }

            return a.petUuid().compareTo(b.petUuid());
        };
        records.sort(comparator);
    }

    public int rescanLoadedForPlayer(class_3222 player) {
        class_3218 targetWorld = player.method_51469();
        MinecraftServer server = targetWorld.method_8503();
        if (server == null) {
            return 0;
        }
        return this.tracker.rescanLoadedPetsForOwner(server, player.method_5667());
    }

    private void processNextRecord(
            class_3222 player,
            MinecraftServer server,
            List<PetRecord> records,
            int index,
            RecallSummary summary,
            Consumer<RecallSummary> onComplete,
            boolean includeLoadedPets
    ) {
        if (index >= records.size()) {
            synchronized (this.activeRecalls) {
                this.activeRecalls.remove(player.method_5667());
            }
            onComplete.accept(summary);
            return;
        }

        if (player.method_31481()) {
            summary.messages.add("Player is no longer available");
            summary.failed += Math.max(0, records.size() - index);
            summary.attempted += Math.max(0, records.size() - index);
            synchronized (this.activeRecalls) {
                this.activeRecalls.remove(player.method_5667());
            }
            onComplete.accept(summary);
            return;
        }

        if (!player.method_24828()) {
            summary.messages.add("Recall stopped: stand on the ground.");
            summary.failed += Math.max(0, records.size() - index);
            summary.attempted += Math.max(0, records.size() - index);
            synchronized (this.activeRecalls) {
                this.activeRecalls.remove(player.method_5667());
            }
            onComplete.accept(summary);
            return;
        }

        PetRecord record = records.get(index);
        if (!this.tryBeginPetRecall(record.petUuid())) {
            summary.messages.add("Pet recall is already in progress for " + record.petUuid());
            summary.failed++;
            this.processNextRecord(player, server, records, index + 1, summary, onComplete, includeLoadedPets);
            return;
        }

        class_1297 loaded = this.tracker.getLoadedPet(record.petUuid());
        if (loaded != null) {
            if (!includeLoadedPets) {
                this.endPetRecall(record.petUuid());
                this.processNextRecord(player, server, records, index + 1, summary, onComplete, includeLoadedPets);
                return;
            }

            summary.attempted++;
            RecallOutcome outcome;
            try {
                outcome = this.recallLoadedPet(player, player.method_51469(), loaded, summary);
            } finally {
                this.endPetRecall(record.petUuid());
            }
            applyOutcome(summary, outcome);
            this.processNextRecord(player, server, records, index + 1, summary, onComplete, includeLoadedPets);
            return;
        }

        summary.attempted++;
        try {
            this.recallUnloadedPetAsync(player, player.method_51469(), server, record, summary, outcome -> {
                try {
                    applyOutcome(summary, outcome);
                } finally {
                    this.endPetRecall(record.petUuid());
                }
                this.processNextRecord(player, server, records, index + 1, summary, onComplete, includeLoadedPets);
            });
        } catch (RuntimeException e) {
            this.endPetRecall(record.petUuid());
            throw e;
        }
    }

    private static void applyOutcome(RecallSummary summary, RecallOutcome outcome) {
        switch (outcome) {
            case RECALLED -> summary.recalled++;
            case SKIPPED -> summary.skipped++;
            case FAILED -> summary.failed++;
        }
    }

    private RecallOutcome recallLoadedPet(class_3222 player, class_3218 targetWorld, class_1297 entity, RecallSummary summary) {
        if (!canContinueRecallForPlayer(player)) {
            return RecallOutcome.FAILED;
        }

        OwnedPetData ownedPet = PetOwnershipUtil.getOwnedPetData(entity);
        if (ownedPet == null) {
            MinecraftServer server = targetWorld.method_8503();
            if (server != null) {
                this.tracker.removeRecord(server, entity.method_5667());
            }
            summary.messages.add("Non-following tamed mob skipped " + entity.method_5667());
            return RecallOutcome.SKIPPED;
        }

        if (!ownedPet.ownerUuid().equals(player.method_5667())) {
            return RecallOutcome.FAILED;
        }

        if (ownedPet.sitting()) {
            summary.messages.add("Sitting pet skipped " + entity.method_5667());
            return RecallOutcome.SKIPPED;
        }

        SafeRecallSpot safeSpot = findSafeRecallPosition(player, targetWorld, entity, summary);
        if (safeSpot == null) {
            summary.messages.add("No safe spot near player for pet " + entity.method_5667());
            return RecallOutcome.FAILED;
        }

        class_1297 teleported = entity.method_5731(new class_5454(
                targetWorld,
                safeSpot.position(),
                class_243.field_1353,
                entity.method_36454(),
                entity.method_36455(),
                class_5454.field_52245
        ));

        if (teleported == null) {
            return RecallOutcome.FAILED;
        }

        reserveRecallSpot(summary, safeSpot);
        this.tracker.upsertRecordFromEntity(targetWorld, teleported);
        return RecallOutcome.RECALLED;
    }

    private void recallUnloadedPetAsync(class_3222 player, class_3218 targetWorld, MinecraftServer server, PetRecord record, RecallSummary summary, Consumer<RecallOutcome> done) {
        RecallOutcome loadedRaceOutcome = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
        if (loadedRaceOutcome != null) {
            done.accept(loadedRaceOutcome);
            return;
        }

        var sourceWorldKey = record.dimensionKey();
        if (sourceWorldKey == null) {
            summary.messages.add("Bad dimension id for pet " + record.petUuid() + ": " + record.dimensionId());
            this.tracker.removeRecord(server, record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        class_3218 sourceWorld = server.method_3847(sourceWorldKey);
        if (sourceWorld == null) {
            summary.messages.add("Source world missing for pet " + record.petUuid() + ": " + sourceWorldKey.method_29177());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        class_5565 dataAccess = getEntityChunkDataAccess(sourceWorld);
        class_3977 storage = ((EntityChunkDataAccessAccessor) dataAccess).pet_recall$getStorage();
        class_1923 chunkPos = record.chunkPos();
        storage.method_23696(chunkPos).whenComplete((chunkNbtOptional, throwable) -> {
            server.execute(() -> {
                if (throwable != null) {
                    PetRecallMod.LOGGER.warn("Failed reading entity chunk data for {} in {}", chunkPos, sourceWorldKey.method_29177(), throwable);
                    summary.messages.add("Read failed for pet " + record.petUuid());
                    done.accept(RecallOutcome.FAILED);
                    return;
                }

                RecallOutcome loadedOutcome = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
                if (loadedOutcome != null) {
                    done.accept(loadedOutcome);
                    return;
                }

                this.finishUnloadedRecallAfterReadRaw(player, targetWorld, server, record, summary, storage, chunkPos, chunkNbtOptional, done);
            });
        });
    }

    private void finishUnloadedRecallAfterReadRaw(
            class_3222 player,
            class_3218 targetWorld,
            MinecraftServer server,
            PetRecord record,
            RecallSummary summary,
            class_3977 storage,
            class_1923 chunkPos,
            Optional<class_2487> chunkNbtOptional,
            Consumer<RecallOutcome> done
    ) {
        if (!canContinueRecallForPlayer(player)) {
            summary.messages.add("Recall cancelled while waiting for pet " + record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        RecallOutcome loadedRaceOutcome = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
        if (loadedRaceOutcome != null) {
            done.accept(loadedRaceOutcome);
            return;
        }

        if (chunkNbtOptional.isEmpty()) {
            done.accept(this.handleMissingIndexedPetData(player, targetWorld, server, record, summary, "Pet chunk data missing for "));
            return;
        }

        class_2487 originalChunkNbt = chunkNbtOptional.get();
        Optional<class_2499> entitiesListOptional = originalChunkNbt.method_10554("Entities");
        if (entitiesListOptional.isEmpty()) {
            done.accept(this.handleMissingIndexedPetData(player, targetWorld, server, record, summary, "Pet not found in indexed chunk " + chunkPos + ": "));
            return;
        }

        class_2499 entitiesList = entitiesListOptional.get();
        int petIndex = -1;
        class_2487 petEntryNbt = null;
        for (int i = 0; i < entitiesList.size(); i++) {
            Optional<class_2487> entryOptional = entitiesList.method_10602(i);
            if (entryOptional.isEmpty()) {
                continue;
            }

            class_2487 entry = entryOptional.get();
            UUID entityUuid = getEntityUuidFromNbt(entry);
            if (entityUuid == null || !entityUuid.equals(record.petUuid())) {
                continue;
            }

            petIndex = i;
            petEntryNbt = entry.method_10553();
            break;
        }

        if (petEntryNbt == null) {
            done.accept(this.handleMissingIndexedPetData(player, targetWorld, server, record, summary, "Pet not found in indexed chunk " + chunkPos + ": "));
            return;
        }

        class_1297 recreated = class_1299.method_71371(petEntryNbt.method_10553(), targetWorld, class_3730.field_16462, e -> e);
        if (recreated == null) {
            summary.messages.add("Failed to recreate pet " + record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        OwnedPetData ownedPet = PetOwnershipUtil.getOwnedPetData(recreated);
        if (ownedPet == null) {
            this.tracker.removeRecord(server, record.petUuid());
            summary.messages.add("Non-following tamed mob skipped " + record.petUuid());
            done.accept(RecallOutcome.SKIPPED);
            return;
        }

        if (!ownedPet.ownerUuid().equals(player.method_5667())) {
            summary.messages.add("Ownership mismatch for pet " + record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        if (ownedPet.sitting()) {
            summary.messages.add("Sitting pet skipped " + record.petUuid());
            done.accept(RecallOutcome.SKIPPED);
            return;
        }

        SafeRecallSpot safeSpot = findSafeRecallPosition(player, targetWorld, recreated, summary);
        if (safeSpot == null) {
            summary.messages.add("No safe spot near player for pet " + record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }

        RecallOutcome loadedOutcomeBeforeWrite = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
        if (loadedOutcomeBeforeWrite != null) {
            done.accept(loadedOutcomeBeforeWrite);
            return;
        }

        class_2487 updatedChunkNbt = originalChunkNbt.method_10553();
        Optional<class_2499> updatedEntitiesOptional = updatedChunkNbt.method_10554("Entities");
        if (updatedEntitiesOptional.isEmpty()) {
            summary.messages.add("Chunk entities list missing during write for pet " + record.petUuid());
            done.accept(RecallOutcome.FAILED);
            return;
        }
        updatedEntitiesOptional.get().remove(petIndex);

        storage.method_17910(chunkPos, updatedChunkNbt).whenComplete((unused, writeThrowable) -> {
            server.execute(() -> {
                if (writeThrowable != null) {
                    PetRecallMod.LOGGER.warn("Failed writing raw entity chunk data after removing pet {}", record.petUuid(), writeThrowable);
                    summary.messages.add("Write failed for pet " + record.petUuid());
                    done.accept(RecallOutcome.FAILED);
                    return;
                }

                if (!canContinueRecallForPlayer(player)) {
                    summary.messages.add("Recall cancelled before spawning pet " + record.petUuid());
                    rollbackRawChunkWrite(storage, server, chunkPos, originalChunkNbt.method_10553(), record.petUuid(), () -> done.accept(RecallOutcome.FAILED));
                    return;
                }

                RecallOutcome loadedOutcomeAfterWrite = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
                if (loadedOutcomeAfterWrite != null) {
                    if (loadedOutcomeAfterWrite == RecallOutcome.RECALLED) {
                        done.accept(loadedOutcomeAfterWrite);
                    } else {
                        rollbackRawChunkWrite(storage, server, chunkPos, originalChunkNbt.method_10553(), record.petUuid(), () -> done.accept(loadedOutcomeAfterWrite));
                    }
                    return;
                }

                recreated.method_60949(safeSpot.position(), recreated.method_36454(), recreated.method_36455());
                boolean spawned = targetWorld.method_30736(recreated);
                if (!spawned) {
                    RecallOutcome loadedOutcomeOnSpawnFail = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
                    if (loadedOutcomeOnSpawnFail != null) {
                        if (loadedOutcomeOnSpawnFail == RecallOutcome.RECALLED) {
                            done.accept(loadedOutcomeOnSpawnFail);
                        } else {
                            rollbackRawChunkWrite(storage, server, chunkPos, originalChunkNbt.method_10553(), record.petUuid(), () -> done.accept(loadedOutcomeOnSpawnFail));
                        }
                        return;
                    }

                    rollbackRawChunkWrite(storage, server, chunkPos, originalChunkNbt.method_10553(), record.petUuid(), () -> done.accept(RecallOutcome.FAILED));
                    summary.messages.add("Failed to spawn pet " + record.petUuid());
                    return;
                }

                reserveRecallSpot(summary, safeSpot);
                this.tracker.upsertRecordFromEntity(targetWorld, recreated);
                done.accept(RecallOutcome.RECALLED);
            });
        });
    }

    private boolean tryBeginPetRecall(UUID petUuid) {
        synchronized (this.activePetRecalls) {
            return this.activePetRecalls.add(petUuid);
        }
    }

    private void endPetRecall(UUID petUuid) {
        synchronized (this.activePetRecalls) {
            this.activePetRecalls.remove(petUuid);
        }
    }

    private static boolean canContinueRecallForPlayer(class_3222 player) {
        return !player.method_31481() && player.method_24828();
    }

    private RecallOutcome handleMissingIndexedPetData(
            class_3222 player,
            class_3218 targetWorld,
            MinecraftServer server,
            PetRecord record,
            RecallSummary summary,
            String messagePrefix
    ) {
        RecallOutcome loadedRaceOutcome = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
        if (loadedRaceOutcome != null) {
            return loadedRaceOutcome;
        }

        this.tracker.rescanLoadedPetsForOwner(server, player.method_5667());
        RecallOutcome loadedAfterRescan = this.tryRecallLoadedIfPresent(player, targetWorld, record.petUuid(), summary);
        if (loadedAfterRescan != null) {
            return loadedAfterRescan;
        }

        summary.messages.add(messagePrefix + record.petUuid());
        return RecallOutcome.FAILED;
    }

    @Nullable
    private RecallOutcome tryRecallLoadedIfPresent(class_3222 player, class_3218 targetWorld, UUID petUuid, RecallSummary summary) {
        class_1297 loaded = this.tracker.getLoadedPet(petUuid);
        if (loaded == null) {
            return null;
        }
        return this.recallLoadedPet(player, targetWorld, loaded, summary);
    }

    @Nullable
    private static UUID getEntityUuidFromNbt(class_2487 entityNbt) {
        return entityNbt.method_10561("UUID").map(class_4844::method_26276).orElse(null);
    }

    private static void rollbackRawChunkWrite(class_3977 storage, MinecraftServer server, class_1923 chunkPos, class_2487 originalChunkNbt, UUID petUuid, Runnable afterRollback) {
        storage.method_17910(chunkPos, originalChunkNbt).whenComplete((unused, rollbackThrowable) -> {
            server.execute(() -> {
                if (rollbackThrowable != null) {
                    PetRecallMod.LOGGER.error("Failed raw rollback for pet {} in chunk {}", petUuid, chunkPos, rollbackThrowable);
                }
                afterRollback.run();
            });
        });
    }

    @Nullable
    private static SafeRecallSpot findSafeRecallPosition(class_3222 player, class_3218 targetWorld, class_1297 pet, RecallSummary summary) {
        if (!(pet instanceof class_1308 mob)) {
            return null;
        }

        class_2338 ownerPos = player.method_24515();
        final int maxRadius = 8;
        final int[] yOffsets = {0, 1, -1, 2, -2};
        SafeRecallSpot bestSpot = null;
        int bestUsage = Integer.MAX_VALUE;

        for (int radius = 2; radius <= maxRadius; radius++) {
            for (int yOffset : yOffsets) {
                for (int x = -radius; x <= radius; x++) {
                    for (int z = -radius; z <= radius; z++) {
                        if (Math.max(Math.abs(x), Math.abs(z)) != radius) {
                            continue;
                        }
                        if (Math.abs(x) < 2 && Math.abs(z) < 2) {
                            continue;
                        }

                        class_2338 candidate = new class_2338(ownerPos.method_10263() + x, ownerPos.method_10264() + yOffset, ownerPos.method_10260() + z);
                        if (!canTeleportTo(targetWorld, mob, candidate)) {
                            continue;
                        }
                        if (!hasLineOfSightToCandidate(player, targetWorld, mob, candidate)) {
                            continue;
                        }

                        int usage = summary.recallSpotUsage.getOrDefault(candidate.method_10063(), 0);
                        class_243 position = new class_243(candidate.method_10263() + 0.5D, candidate.method_10264(), candidate.method_10260() + 0.5D);
                        if (usage < bestUsage) {
                            bestUsage = usage;
                            bestSpot = new SafeRecallSpot(candidate, position);
                            if (bestUsage == 0) {
                                return bestSpot;
                            }
                        }
                    }
                }
            }
        }

        // Last fallback: directly under the player (requested), still must be a physically safe spot.
        class_2338 underPlayer = ownerPos;
        if (canTeleportTo(targetWorld, mob, underPlayer, true)) {
            int usage = summary.recallSpotUsage.getOrDefault(underPlayer.method_10063(), 0);
            class_243 position = new class_243(player.method_23317(), underPlayer.method_10264(), player.method_23321());
            SafeRecallSpot fallback = new SafeRecallSpot(underPlayer, position);
            if (bestSpot == null || usage <= bestUsage) {
                return fallback;
            }
        }

        return bestSpot;
    }

    private static boolean canTeleportTo(class_3218 targetWorld, class_1308 mob, class_2338 pos) {
        return canTeleportTo(targetWorld, mob, pos, false);
    }

    private static boolean canTeleportTo(class_3218 targetWorld, class_1308 mob, class_2338 pos, boolean ignoreEntityCollisions) {
        class_7 nodeType = class_14.method_57625(mob, pos);
        if (nodeType != class_7.field_12) {
            return false;
        }

        class_2680 belowState = targetWorld.method_8320(pos.method_10074());
        if (belowState.method_26204() instanceof class_2397) {
            return false;
        }

        class_2338 relative = pos.method_10059(mob.method_24515());
        class_238 targetBox = mob.method_5829().method_996(relative);
        if (boxContainsFluid(targetWorld, targetBox)) {
            return false;
        }

        return ignoreEntityCollisions
                ? targetWorld.method_18026(targetBox)
                : targetWorld.method_8587(mob, targetBox);
    }

    private static boolean boxContainsFluid(class_3218 world, class_238 box) {
        // Check every block cell intersecting the destination hitbox to avoid teleporting into fluids/waterlogged blocks.
        for (class_2338 blockPos : class_2338.method_62671(box)) {
            if (!world.method_8316(blockPos).method_15769()) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasLineOfSightToCandidate(class_3222 player, class_3218 world, class_1308 mob, class_2338 candidate) {
        class_243 start = new class_243(player.method_23317(), player.method_23320(), player.method_23321());
        double targetY = candidate.method_10264() + Math.min(1.0D, Math.max(0.25D, mob.method_17682() * 0.5D));
        class_243 end = new class_243(candidate.method_10263() + 0.5D, targetY, candidate.method_10260() + 0.5D);
        class_239 hit = world.method_17742(new class_3959(
                start,
                end,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    private static void reserveRecallSpot(RecallSummary summary, SafeRecallSpot safeSpot) {
        long key = safeSpot.blockPos().method_10063();
        summary.recallSpotUsage.merge(key, 1, Integer::sum);
    }

    private static class_5565 getEntityChunkDataAccess(class_3218 world) {
        class_5579<class_1297> entityManager = ((ServerWorldAccessor) world).pet_recall$getEntityManager();
        @SuppressWarnings("unchecked")
        class_5571<class_1297> dataAccess = ((ServerEntityManagerAccessor<class_1297>) (Object) entityManager).pet_recall$getDataAccess();
        if (dataAccess instanceof class_5565 entityChunkDataAccess) {
            return entityChunkDataAccess;
        }
        throw new IllegalStateException("Unexpected entity data access: " + dataAccess.getClass().getName());
    }

    public static final class RecallSummary {
        private static final List<String> NO_OP_MESSAGES = new AbstractList<>() {
            @Override
            public String get(int index) {
                throw new IndexOutOfBoundsException(index);
            }

            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean add(String element) {
                return true;
            }
        };

        public int totalKnown;
        public int attempted;
        public int recalled;
        public int skipped;
        public int failed;
        public final List<String> messages;
        private final Map<Long, Integer> recallSpotUsage = new HashMap<>();

        public RecallSummary() {
            this(true);
        }

        public RecallSummary(boolean collectMessages) {
            this.messages = collectMessages ? new ArrayList<>() : NO_OP_MESSAGES;
        }
    }

    private enum RecallOutcome {
        RECALLED,
        SKIPPED,
        FAILED
    }

    private record SafeRecallSpot(class_2338 blockPos, class_243 position) {
    }
}
