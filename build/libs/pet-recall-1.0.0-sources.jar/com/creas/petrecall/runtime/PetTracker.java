package com.creas.petrecall.runtime;

import com.creas.petrecall.PetRecallMod;
import com.creas.petrecall.index.PetIndexState;
import com.creas.petrecall.index.PetRecord;
import com.creas.petrecall.util.PetOwnershipUtil;
import com.creas.petrecall.util.PetOwnershipUtil.OwnedPetData;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public final class PetTracker {
    private final Map<UUID, class_1297> loadedPets = new ConcurrentHashMap<>();

    public void onEntityLoad(class_1297 entity, class_3218 world) {
        this.observe(entity, world);
    }

    public void onEntityUnload(class_1297 entity, class_3218 world) {
        this.observe(entity, world);
        this.loadedPets.remove(entity.method_5667(), entity);
    }

    public void clearRuntime() {
        this.loadedPets.clear();
    }

    public void observe(class_1297 entity, class_3218 world) {
        OwnedPetData ownedPet = PetOwnershipUtil.getOwnedPetData(entity);
        MinecraftServer server = world.method_8503();
        if (ownedPet == null) {
            this.loadedPets.remove(entity.method_5667(), entity);
            if (server != null) {
                PetIndexState.get(server).remove(entity.method_5667());
            }
            return;
        }

        if (server == null) {
            return;
        }

        this.loadedPets.put(entity.method_5667(), entity);
        PetIndexState state = PetIndexState.get(server);
        state.put(PetRecord.fromEntity(world, entity, ownedPet.ownerUuid(), ownedPet.sitting(), ownedPet.health()));
    }

    @Nullable
    public class_1297 getLoadedPet(UUID petUuid) {
        class_1297 entity = this.loadedPets.get(petUuid);
        if (entity == null || entity.method_31481()) {
            this.loadedPets.remove(petUuid);
            return null;
        }
        return entity;
    }

    public Collection<PetRecord> getOwnerRecords(MinecraftServer server, UUID ownerUuid) {
        return PetIndexState.get(server).getPetsForOwner(ownerUuid);
    }

    public void removeRecord(MinecraftServer server, UUID petUuid) {
        this.loadedPets.remove(petUuid);
        PetIndexState.get(server).remove(petUuid);
    }

    public void upsertRecordFromEntity(class_3218 world, class_1297 entity) {
        this.observe(entity, world);
    }

    public int rescanLoadedPetsForOwner(MinecraftServer server, UUID ownerUuid) {
        int found = 0;
        for (class_3218 world : server.method_3738()) {
            for (class_1297 entity : world.method_27909()) {
                OwnedPetData ownedPet = PetOwnershipUtil.getOwnedPetData(entity);
                if (ownedPet != null && ownedPet.ownerUuid().equals(ownerUuid)) {
                    this.observe(entity, world);
                    found++;
                }
            }
        }
        return found;
    }

    public int getLoadedPetCount() {
        return this.loadedPets.size();
    }
}
