package com.creas.petrecall.mixin.accessor;

import net.minecraft.class_3977;
import net.minecraft.class_5565;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5565.class)
public interface EntityChunkDataAccessAccessor {
    @Accessor("storage")
    class_3977 pet_recall$getStorage();
}
