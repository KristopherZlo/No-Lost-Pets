package com.creas.petrecall.mixin.accessor;

import net.minecraft.class_5568;
import net.minecraft.class_5571;
import net.minecraft.class_5579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5579.class)
public interface ServerEntityManagerAccessor<T extends class_5568> {
    @Accessor("dataAccess")
    class_5571<T> pet_recall$getDataAccess();
}
