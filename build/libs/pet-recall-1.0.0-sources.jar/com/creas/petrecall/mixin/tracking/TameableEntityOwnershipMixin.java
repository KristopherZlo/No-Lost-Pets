package com.creas.petrecall.mixin.tracking;

import com.creas.petrecall.PetRecallMod;
import net.minecraft.class_10583;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1321.class)
public abstract class TameableEntityOwnershipMixin {
    @Inject(method = "setOwner(Lnet/minecraft/entity/LivingEntity;)V", at = @At("TAIL"))
    private void pet_recall$afterSetOwnerEntity(class_1309 owner, CallbackInfo ci) {
        this.pet_recall$refreshTracker();
    }

    @Inject(method = "setOwner(Lnet/minecraft/entity/LazyEntityReference;)V", at = @At("TAIL"))
    private void pet_recall$afterSetOwnerReference(class_10583<class_1309> ownerReference, CallbackInfo ci) {
        this.pet_recall$refreshTracker();
    }

    @Inject(method = "setTamedBy(Lnet/minecraft/entity/player/PlayerEntity;)V", at = @At("TAIL"))
    private void pet_recall$afterSetTamedBy(class_1657 player, CallbackInfo ci) {
        this.pet_recall$refreshTracker();
    }

    private void pet_recall$refreshTracker() {
        class_1297 self = (class_1297) (Object) this;
        if (self.method_73183() instanceof class_3218 serverWorld) {
            PetRecallMod.getTracker().observe(self, serverWorld);
        }
    }
}
