package com.creas.petrecall.mixin.tracking;

import com.creas.petrecall.PetRecallMod;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1496.class)
public abstract class AbstractHorseOwnershipMixin {
    @Inject(method = "setOwner(Lnet/minecraft/entity/LivingEntity;)V", at = @At("TAIL"))
    private void pet_recall$afterSetOwner(class_1309 owner, CallbackInfo ci) {
        this.pet_recall$refreshTracker();
    }

    @Inject(method = "bondWithPlayer", at = @At("TAIL"))
    private void pet_recall$afterBondWithPlayer(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        this.pet_recall$refreshTracker();
    }

    private void pet_recall$refreshTracker() {
        class_1297 self = (class_1297) (Object) this;
        if (self.method_73183() instanceof class_3218 serverWorld) {
            PetRecallMod.getTracker().observe(self, serverWorld);
        }
    }
}
