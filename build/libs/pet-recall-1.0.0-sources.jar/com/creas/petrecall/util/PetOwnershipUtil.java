package com.creas.petrecall.util;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_10583;
import net.minecraft.class_11362;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1496;
import net.minecraft.class_2487;
import net.minecraft.class_4844;
import net.minecraft.class_8046;
import net.minecraft.class_8942;
import org.jetbrains.annotations.Nullable;

public final class PetOwnershipUtil {
    private static final List<String> OWNER_UUID_KEYS = List.of(
            "Owner",
            "OwnerUUID",
            "OwnerUuid",
            "owner",
            "ownerUUID",
            "ownerUuid",
            "owner_uuid"
    );
    private static final List<String> SITTING_KEYS = List.of(
            "Sitting",
            "OrderedToSit",
            "IsSitting",
            "isSitting",
            "is_sitting"
    );

    private PetOwnershipUtil() {
    }

    @Nullable
    public static OwnedPetData getOwnedPetData(class_1297 entity) {
        if (entity instanceof class_1321 tameable) {
            if (!tameable.method_6181()) {
                return null;
            }
            UUID ownerUuid = getOwnerUuid(tameable.method_66287());
            if (ownerUuid == null) {
                return null;
            }
            float health = tameable.method_6032();
            return new OwnedPetData(ownerUuid, tameable.method_24345(), health);
        }

        // Tamed mounts (horse/donkey/mule/llama/camel/etc.) do not have companion follow-to-owner behavior.
        if (entity instanceof class_1496) {
            return null;
        }

        if (!(entity instanceof class_1309 living)) {
            return null;
        }

        UUID ownerUuid = null;
        if (entity instanceof class_8046 ownable) {
            ownerUuid = getOwnerUuid(ownable.method_24921());
        }
        class_2487 entityNbt = null;
        if (ownerUuid == null) {
            entityNbt = writeEntityNbt(entity);
            ownerUuid = findOwnerUuidInNbt(entityNbt);
        }
        if (ownerUuid == null) {
            return null;
        }

        if (entityNbt == null) {
            entityNbt = writeEntityNbt(entity);
        }
        if (!hasCompanionFollowSignalsInNbt(entityNbt)) {
            return null;
        }

        boolean sitting = isSittingFromNbt(entityNbt);
        return new OwnedPetData(ownerUuid, sitting, living.method_6032());
    }

    @Nullable
    private static UUID getOwnerUuid(@Nullable class_1297 owner) {
        return owner == null ? null : owner.method_5667();
    }

    @Nullable
    private static UUID findOwnerUuidInNbt(@Nullable class_2487 nbt) {
        if (nbt == null) {
            return null;
        }

        for (String key : OWNER_UUID_KEYS) {
            UUID uuid = tryReadUuid(nbt, key);
            if (uuid != null) {
                return uuid;
            }
        }

        UUID uuidFromLongPair = tryReadUuidFromLongPair(nbt, "OwnerUUIDMost", "OwnerUUIDLeast");
        if (uuidFromLongPair != null) {
            return uuidFromLongPair;
        }
        uuidFromLongPair = tryReadUuidFromLongPair(nbt, "OwnerMost", "OwnerLeast");
        if (uuidFromLongPair != null) {
            return uuidFromLongPair;
        }
        uuidFromLongPair = tryReadUuidFromLongPair(nbt, "ownerMost", "ownerLeast");
        if (uuidFromLongPair != null) {
            return uuidFromLongPair;
        }

        return null;
    }

    private static boolean isSittingFromNbt(@Nullable class_2487 nbt) {
        if (nbt == null) {
            return false;
        }

        for (String key : SITTING_KEYS) {
            OptionalBoolean sitting = tryReadBoolean(nbt, key);
            if (sitting.present()) {
                return sitting.value();
            }
        }

        OptionalByte command = tryReadByte(nbt, "Command");
        if (command.present()) {
            return command.value() == 1;
        }

        return false;
    }

    private static boolean hasCompanionFollowSignalsInNbt(@Nullable class_2487 nbt) {
        if (nbt == null) {
            return false;
        }

        for (String key : SITTING_KEYS) {
            if (tryReadBoolean(nbt, key).present()) {
                return true;
            }
        }

        return tryReadByte(nbt, "Command").present();
    }

    @Nullable
    private static UUID getOwnerUuid(@Nullable class_10583<class_1309> ownerReference) {
        if (ownerReference == null) {
            return null;
        }
        return ownerReference.method_66263();
    }

    @Nullable
    private static class_2487 writeEntityNbt(class_1297 entity) {
        try {
            class_11362 view = class_11362.method_71458(class_8942.field_60348);
            if (!entity.method_5662(view)) {
                return null;
            }
            return view.method_71475();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    @Nullable
    private static UUID tryReadUuid(class_2487 nbt, String key) {
        var intArray = nbt.method_10561(key);
        if (intArray.isPresent()) {
            int[] value = intArray.get();
            if (value.length == 4) {
                return class_4844.method_26276(value);
            }
        }

        var stringValue = nbt.method_10558(key);
        if (stringValue.isPresent()) {
            try {
                return UUID.fromString(stringValue.get());
            } catch (IllegalArgumentException ignored) {
                // Ignore malformed UUID strings.
            }
        }

        return null;
    }

    @Nullable
    private static UUID tryReadUuidFromLongPair(class_2487 nbt, String mostKey, String leastKey) {
        var most = nbt.method_10537(mostKey);
        var least = nbt.method_10537(leastKey);
        if (most.isEmpty() || least.isEmpty()) {
            return null;
        }
        return new UUID(most.get(), least.get());
    }

    private static OptionalBoolean tryReadBoolean(class_2487 nbt, String key) {
        var value = nbt.method_10577(key);
        if (value.isEmpty()) {
            return OptionalBoolean.empty();
        }
        return OptionalBoolean.of(value.get());
    }

    private static OptionalByte tryReadByte(class_2487 nbt, String key) {
        var value = nbt.method_10571(key);
        if (value.isEmpty()) {
            return OptionalByte.empty();
        }
        return OptionalByte.of(value.get());
    }

    private record OptionalBoolean(boolean present, boolean value) {
        private static OptionalBoolean empty() {
            return new OptionalBoolean(false, false);
        }

        private static OptionalBoolean of(boolean value) {
            return new OptionalBoolean(true, value);
        }
    }

    private record OptionalByte(boolean present, byte value) {
        private static OptionalByte empty() {
            return new OptionalByte(false, (byte) 0);
        }

        private static OptionalByte of(byte value) {
            return new OptionalByte(true, value);
        }
    }

    public record OwnedPetData(UUID ownerUuid, boolean sitting, float health) {
    }
}
