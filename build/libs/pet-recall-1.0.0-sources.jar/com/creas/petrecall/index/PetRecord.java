package com.creas.petrecall.index;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.UUID;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;

public record PetRecord(
        UUID petUuid,
        UUID ownerUuid,
        String entityTypeId,
        String dimensionId,
        long chunkPosLong,
        double x,
        double y,
        double z,
        boolean sitting,
        float health
) {
    public static final Codec<PetRecord> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_4844.field_40825.fieldOf("pet_uuid").forGetter(PetRecord::petUuid),
            class_4844.field_40825.fieldOf("owner_uuid").forGetter(PetRecord::ownerUuid),
            Codec.STRING.fieldOf("entity_type").forGetter(PetRecord::entityTypeId),
            Codec.STRING.fieldOf("dimension").forGetter(PetRecord::dimensionId),
            Codec.LONG.fieldOf("chunk_pos").forGetter(PetRecord::chunkPosLong),
            Codec.DOUBLE.fieldOf("x").forGetter(PetRecord::x),
            Codec.DOUBLE.fieldOf("y").forGetter(PetRecord::y),
            Codec.DOUBLE.fieldOf("z").forGetter(PetRecord::z),
            Codec.BOOL.optionalFieldOf("sitting", false).forGetter(PetRecord::sitting),
            Codec.FLOAT.optionalFieldOf("health", 0.0F).forGetter(PetRecord::health)
    ).apply(instance, PetRecord::new));

    public static PetRecord fromEntity(class_3218 world, net.minecraft.class_1297 entity, UUID ownerUuid, boolean sitting, float health) {
        return new PetRecord(
                entity.method_5667(),
                ownerUuid,
                class_7923.field_41177.method_10221(entity.method_5864()).toString(),
                world.method_27983().method_29177().toString(),
                entity.method_31476().method_8324(),
                entity.method_23317(),
                entity.method_23318(),
                entity.method_23321(),
                sitting,
                health
        );
    }

    public class_1923 chunkPos() {
        return new class_1923(this.chunkPosLong);
    }

    @Nullable
    public class_5321<class_1937> dimensionKey() {
        class_2960 id = class_2960.method_12829(this.dimensionId);
        if (id == null) {
            return null;
        }
        return class_5321.method_29179(class_7924.field_41223, id);
    }
}
